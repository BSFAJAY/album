import './App.css';
import './index.css';
import Detail from './components/Detail';
import { useEffect } from 'react';

function App() {

  return (
    <>
      < Detail />
    </>
  )
}

export default App
